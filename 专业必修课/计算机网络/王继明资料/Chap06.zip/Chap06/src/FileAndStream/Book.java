package FileAndStream;
import java.io.*;
public class Book implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int id;
	String name;
	String author;
	double price;
//	transient int borrowerID;
	int borrowerID;
	
	public Book(int id, String name, String author, double price) {
		this.id = id;
		this.name = name;
		this.author = author;
		this.price = price;
	}
	public Book(){
		this.id = 0;
		this.name = null;
		this.author = null;
		this.price = 0.0;
	}
	public void borrowBook(int ID){
		this.borrowerID = ID;
	}
}

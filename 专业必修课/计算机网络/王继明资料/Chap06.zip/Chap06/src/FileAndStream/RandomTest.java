package FileAndStream;
//import java.io.*;
public class RandomTest {
    public static void main(String[] args) {
        String fileName = "F:/Java/Chap06/newTemp.txt";
        ReadRandomFile.readFileByRandomAccess(fileName);
    }
}

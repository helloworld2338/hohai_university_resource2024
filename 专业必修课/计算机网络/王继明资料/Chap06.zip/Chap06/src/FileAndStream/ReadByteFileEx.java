package FileAndStream;
import java.io.*;
public class ReadByteFileEx {
    public static void main ( String[] args ) {
 	   String fileName = "F:/Java/Chap06/data2.dat";
 	   int sum = 0;
       try {  DataInputStream instr = new DataInputStream(new BufferedInputStream(new FileInputStream(fileName)));
               sum += instr.readInt();
               sum += instr.readDouble();  
               sum += instr.readInt();
               System.out.println( "The sum is: " + sum );
               instr.close();         }
       catch ( IOException iox ) {
 	        System.out.println("Problem reading " + fileName ); } 
      }
}

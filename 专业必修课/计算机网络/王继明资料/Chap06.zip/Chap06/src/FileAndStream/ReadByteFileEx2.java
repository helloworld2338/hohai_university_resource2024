package FileAndStream;
import java.io.*;
public class ReadByteFileEx2 {
	  public static void main ( String[] args ) {
	        String fileName = "F:/Java/Chap06/book.dat" ; 
	        long sum = 0;
	        try {
	    	    DataInputStream instr = new DataInputStream(new BufferedInputStream(new FileInputStream(fileName)));
	               try {
	                        while ( true )
	                        sum += instr.readByte();
	                }
	                catch ( EOFException  eof ) {
	                         System.out.println( "The sum is: " + sum );
	                         instr.close();
	                 }
	       }
	       catch ( IOException iox ) {
	             System.out.println("IO Problems with " + fileName ); 
	       }
	  }
}

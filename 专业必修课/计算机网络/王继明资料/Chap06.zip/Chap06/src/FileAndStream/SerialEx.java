package FileAndStream;
import java.io.*;
public class SerialEx {
    public static void main(String args[]) throws IOException, ClassNotFoundException {
//      Book book = new Book(100032,"Java Programming Skills", "Wang Sir", 30.0);
//      book.borrowBook(2014);
//      ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("F:/Java/Chap06/book4.dat"));       
//      oos.writeObject(book);
//      oos.close(); 
      Book book = null;
      
      ObjectInputStream ois = new ObjectInputStream(new FileInputStream("F:/Java/Chap06/book3.dat"));    
      book=(Book)ois.readObject(); 
     ois.close(); 

     System.out.println("BorrowerID is: " + book.borrowerID);
    System.out.println("ID is:" + book.id);  
     System.out.println("name is:" + book.name);
      System.out.println("author is:" + book.author);
      System.out.println("price is:" + book.price);
   }
}

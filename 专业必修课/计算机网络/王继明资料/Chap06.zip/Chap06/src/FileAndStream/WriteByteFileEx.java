package FileAndStream;
import java.io.*;
public class WriteByteFileEx {
	public static void main ( String[] args ) { 
	     String fileName = "F:/Java/Chap06/data2.dat" ;
	     int value0  = 254, value1  = 1, value2 = -1;
	     try {
	        DataOutputStream out = new DataOutputStream(new FileOutputStream(fileName));
	        out.writeDouble( value0 );
	        out.writeInt( value1 );
	        out.writeInt( value2 );
	        out.close();
	      }
	      catch ( IOException iox ){
	     	 System.out.println("Problem writing " + fileName );   }
	      }
}

package FileAndStream;
import java.io.*;
public class WriteByteFileEx2 {
	  public static void main ( String[] args ) throws IOException {
	    	String fileName = "F:/Java/Chap06/mixedTypes.dat" ;
	    	DataOutputStream dataOut = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(fileName)));
	    	dataOut.writeDouble( 255 );
	    	System.out.println( dataOut.size()  + " bytes have been written.");
	    	dataOut.writeDouble( 31.2 );
	    	System.out.println( dataOut.size()  + " bytes have been written.");
	    	dataOut.writeBytes("Java");
	    	System.out.println( dataOut.size()  + " bytes have been written.");
	    	dataOut.close();
	  }
}

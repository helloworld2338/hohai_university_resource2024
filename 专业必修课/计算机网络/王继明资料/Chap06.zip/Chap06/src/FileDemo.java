 
import java.io.*;
import java.util.*;
 
public class FileDemo {
    public static void main(String[] args) {
       
            File file = new File("F:/Java/Chap06/data1.dat");
            if(file.isFile()) { // �Ƿ�Ϊ�ļ�
                System.out.println(" �ļ�"); 
                System.out.print(
                      file.canRead() ? "�ɶ�" : "���ɶ�"); 
                System.out.print(
                      file.canWrite() ? "��д" : "����д"); 
                System.out.println(
                      file.length() + "�ֽ�"); 
            } 
            else { 
                // �г����е��ļ���Ŀ¼
                File[] files = file.listFiles(); 
                ArrayList<File> fileList = 
                                    new ArrayList<File>(); 
                for(int i = 0; i < files.length; i++) { 
                    // ���г�Ŀ¼ 
                    if(files[i].isDirectory()) { //�Ƿ�ΪĿ¼
                        // ȡ��·����
                        System.out.println("[" + 
                                files[i].getPath() + "]"); 
                    }
                    else {
                        // �ļ��ȴ���fileList���������г�??
                        fileList.add(files[i]); 
                    }
                } 
 
                // �г��ļ� 
                for(File f: fileList) {
                    System.out.println(f.toString());
                }
                System.out.println(); 
            } 
        
       
    }
}
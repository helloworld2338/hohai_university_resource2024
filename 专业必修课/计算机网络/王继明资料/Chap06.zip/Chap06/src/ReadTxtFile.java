import java.io.*;

public class ReadTxtFile {
	public static void main(String[] args) {
		String fileName = "F:\\Java\\Chap06\\poem2.txt";
		try {
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String line = in.readLine();
			while (line != null) {
				System.out.println(line);
				line = in.readLine();
			}
		}
		catch(IOException iox) {
			System.out.println("Problem Reading: "+ fileName);
		}
	}
}
